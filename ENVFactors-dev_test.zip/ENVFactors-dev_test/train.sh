#!/bin/bash

# Activate the first Conda environment
echo "Activating default Conda environment..."
source activate dev

# Execute the first Python script
echo "Running custom CNN ..."
python /home/orin/github_folder/ENVFactors/'Custom CNN'/jtoptrain.py

# Execute the second Python script
echo "Running image classification..."
python /home/orin/github_folder/ENVFactors/'Image Classification'/train.py --arch "resnet18"
python /home/orin/github_folder/ENVFactors/'Image Classification'/train.py --arch "resnet50"
python /home/orin/github_folder/ENVFactors/'Image Classification'/train.py --arch "densenet"
python /home/orin/github_folder/ENVFactors/'Image Classification'/train.py --arch "mobilenet"

# Execute the first Python script
echo "Running custom ObjdDet"
python /home/orin/github_folder/ENVFactors/'Custom Object detector'/train.py


# Deactivate the first Conda environment
echo "Deactivating default Conda environment..."
conda deactivate


conda init

# Activate the second Conda environment
echo "Activating special_env for the last script..."
source activate tfl

# Execute the last Python script in a different Conda environment
echo "Running script3.py in special_env..."
python /home/orin/github_folder/ENVFactors/'Pix2Pix (Tensorflow)'/train.py



echo "All scripts executed successfully!"
