
**You need ethernet connection before you start the following steps**
1. https://learn.sparkfun.com/tutorials/adding-wifi-to-the-nvidia-jetson/driver-installation 
Follow the instructions with dkms mode only, you need to run 
1. sudo apt-get update && sudo apt-get upgrade
2. sudo apt-get install dkms before installing the wifi drive

Disable sleep mode 
```
sudo systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target
```

Enable passwordless login by going to settings --> user --> toggle off the require password for login 

Go to connection,edit the conenctions,raise the priority of the connection to 9, the number does not matter

Setup for static ip if needed and reboot 

Note: The external wifi adapter is not reliable and at times will show as connected however it will not be connected
