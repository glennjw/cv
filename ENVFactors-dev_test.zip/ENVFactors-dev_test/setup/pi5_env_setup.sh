# get a fresh start
sudo apt-get update
sudo apt-get install -y python3-pip libjpeg-dev libopenblas-dev libopenmpi-dev libomp-dev libhdf5-serial-dev hdf5-tools libhdf5-dev
# activate the virtual environment now.
python3 -m venv /home/pi/Documents/venv_envfactors
py_venv='/home/pi/Documents/venv_envfactors/bin/python3'
$py_venv -m pip install setuptools numpy Cython
$py_venv -m pip install requests
# install PyTorch and Torchvision
$py_venv -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
# you may like to install Torchaudio also
$py_venv -m pip install torchaudio --index-url https://download.pytorch.org/whl/cpu

# install tensorflow
python3 -m pip install --upgrade tensorflow==2.14.0

