
The code to containerize the gan running on jetson nano can be found in this folder along with the Dockerfile and source code "index.py".

To build the container
1. docker build -t <docker id>/imagename:tag 
2. docker run -it -v /run/jtop.sock:/run/jtop.sock --runtime nvidia sushruth13/torch-gan:nano

Please note that you need to configure your jetson device to use nvidia runtime as default
Follow the instructions here 
https://github.com/dusty-nv/jetson-containers/blob/master/docs/setup.md

and jetson-stats need to be put up in it. 

Currently a working docker image is hosted at sushruth13/torch-gan:nano for all jetson nanos and for orin the working image is sushruth13/torch-gan:orin. 

To use this image do as folllows
1. docker pull sushruth13/torch-gan:nano 
2. docker run -it -v /run/jtop.sock:/run/jtop.sock --runtime nvidia sushruth13/torch-gan:nano
