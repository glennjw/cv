import tensorflow as tf
import numpy as np
import csv
import argparse
import datetime
import os
from jtop import jtop, JtopException

# Check for a GPU
device = "/gpu:0" if tf.config.list_physical_devices('GPU') else "/cpu:0"

# Load and preprocess MNIST dataset
mnist = tf.keras.datasets.mnist
(_, _), (x_test, y_test) = mnist.load_data()
x_test = x_test / 255.0

# Normalize the dataset
x_test = (x_test - 0.5) / 0.5
x_test = x_test[..., tf.newaxis]

# Define a simple convolutional neural network
model = tf.keras.models.Sequential([
    tf.keras.layers.Conv2D(32, kernel_size=3, strides=1, padding='same', activation='relu', input_shape=(28, 28, 1)),
    tf.keras.layers.MaxPooling2D(pool_size=2, strides=2),
    tf.keras.layers.Conv2D(64, kernel_size=3, strides=1, padding='same', activation='relu'),
    tf.keras.layers.MaxPooling2D(pool_size=2, strides=2),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(1000, activation='relu'),
    tf.keras.layers.Dense(10)
])

directory = "./CNNlogs"
if not os.path.exists(directory):
    os.makedirs(directory)
# Construct the full path with the timestamp

weights_path = os.path.join(directory, f"model_weights_1.h5")
# Load the trained model weights
model.load_weights(weights_path)

# Prepare the test dataset
test_dataset = tf.data.Dataset.from_tensor_slices((x_test, y_test)).batch(64)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='TensorFlow Inference with jtop Logger')
    parser.add_argument('--file', action="store", dest="file", default="inf_log.csv")
    args = parser.parse_args()

    # Get the start date and time for the filename
    start_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    # Specify a different directory
    directory = "./CNNlogs"
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Construct the full path with the timestamp
    file_path = os.path.join(directory, f"cnninf_log_{start_time}.csv")

    print("Running inference on MNIST with jtop logging")
    print(f"Saving log on {file_path}")

    try:
        with jtop() as jetson:
            with open(file_path, 'w') as csvfile:
                stats = jetson.stats
                writer = csv.DictWriter(csvfile, fieldnames=stats.keys())
                writer.writeheader()

                for i, (images, labels) in enumerate(test_dataset):
                    with tf.device(device):
                        predictions = model(images, training=False)
                        loss = tf.keras.losses.sparse_categorical_crossentropy(labels, predictions)
                        accuracy = tf.keras.metrics.sparse_categorical_accuracy(labels, predictions)

                    # Log every batch
                    if i % 10 == 0:
                        stats = jetson.stats
                        writer.writerow(stats)
                        print(f'Batch {i+1}, Loss: {tf.reduce_mean(loss).numpy():.4f}, Accuracy: {tf.reduce_mean(accuracy).numpy():.4f}')
                        print(f"Log at {stats['time']}")

                # Get the end date and time for the filename
                end_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
                new_file_path = os.path.join(directory, f"cnninf_log_{start_time}_to_{end_time}.csv")
                os.rename(file_path, new_file_path)
                print(f"Log file saved as {new_file_path}")

    except JtopException as e:
        print(e)
    except KeyboardInterrupt:
        print("Inference interrupted with CTRL-C")
    except IOError:
        print("I/O error")