import torch
import torchvision
import torchvision.transforms as transforms
from torch import nn, optim
from torch.utils.data import DataLoader
from jtop import jtop, JtopException
import csv
import argparse
import numpy as np
import numpy
import datetime  
import os

# Check for a GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Transform for the MNIST data
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

# Load MNIST dataset
train_set = torchvision.datasets.MNIST(root='./data', train=True, download=True, transform=transform)
train_loader = DataLoader(train_set, batch_size=64, shuffle=True)

# Define a simple convolutional neural network
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.layers = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Flatten(),
            nn.Linear(64 * 7 * 7, 1000),
            nn.ReLU(),
            nn.Linear(1000, 10)
        )
    
    def forward(self, x):
        return self.layers(x)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='PyTorch Training with jtop Logger')
    parser.add_argument('--file', action="store", dest="file", default="cnnlog.csv")
    args = parser.parse_args()

    # Get the current date and time for the filename
    current_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    # Specify a different directory

    directory = "./CNNlogs"
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Construct the full path with the timestamp
    file_path = os.path.join(directory, f"cnnlog_{current_time}.csv")

    model = CNN().to(device)
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()

    print("Training MNIST with jtop logging")
    print("Saving log on {file}".format(file=args.file))

    try:
        with jtop() as jetson:
            with open(file_path, 'w') as csvfile:
                stats = jetson.stats
                writer = csv.DictWriter(csvfile, fieldnames=stats.keys())
                writer.writeheader()
                
                for epoch in range(5):  # Run 5 epochs
                    for i, (images, labels) in enumerate(train_loader):
                        images = images.to(device)
                        labels = labels.to(device)

                        outputs = model(images)
                        loss = criterion(outputs, labels)

                        optimizer.zero_grad()
                        loss.backward()
                        optimizer.step()

                        # Log every 10 batches
                        if i % 10 == 0:
                            stats = jetson.stats
                            writer.writerow(stats)
                            print(f'Epoch {epoch+1}, Batch {i+1}, Loss: {loss.item():.4f}')
                            print("Log at {time}".format(time=stats['time']))

    except JtopException as e:
        print(e)
    except KeyboardInterrupt:
        print("Training interrupted with CTRL-C")
    except IOError:
        print("I/O error")