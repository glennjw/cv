import tensorflow as tf
import numpy as np
import csv
import argparse
import datetime
import os
from jtop import jtop, JtopException

# Check for a GPU
device = "/gpu:0" if tf.config.list_physical_devices('GPU') else "/cpu:0"

# Load and preprocess MNIST dataset
mnist = tf.keras.datasets.mnist
(x_train, y_train), (_, _) = mnist.load_data()
x_train = x_train / 255.0

# Normalize the dataset
x_train = (x_train - 0.5) / 0.5
x_train = x_train[..., tf.newaxis]

# Define a simple convolutional neural network
model = tf.keras.models.Sequential([
    tf.keras.layers.Conv2D(32, kernel_size=3, strides=1, padding='same', activation='relu', input_shape=(28, 28, 1)),
    tf.keras.layers.MaxPooling2D(pool_size=2, strides=2),
    tf.keras.layers.Conv2D(64, kernel_size=3, strides=1, padding='same', activation='relu'),
    tf.keras.layers.MaxPooling2D(pool_size=2, strides=2),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(1000, activation='relu'),
    tf.keras.layers.Dense(10)
])

loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)
optimizer = tf.keras.optimizers.Adam(learning_rate=0.001)

model.compile(optimizer=optimizer, loss=loss_fn, metrics=['accuracy'])

train_dataset = tf.data.Dataset.from_tensor_slices((x_train, y_train)).batch(64).shuffle(buffer_size=1024)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='TensorFlow Training with jtop Logger')
    parser.add_argument('--file', action="store", dest="file", default="cnnlog.csv")
    args = parser.parse_args()

    # Get the start date and time for the filename
    start_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    # Specify a different directory
    directory = "./CNNlogs"
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Construct the full path with the timestamp
    file_path = os.path.join(directory, f"cnnlog_{start_time}.csv")
    weights_path = os.path.join(directory, f"model_weights_1.h5")

    print("Training MNIST with jtop logging")
    print(f"Saving log on {file_path}")

    try:
        with jtop() as jetson:
            with open(file_path, 'w') as csvfile:
                stats = jetson.stats
                writer = csv.DictWriter(csvfile, fieldnames=stats.keys())
                writer.writeheader()

                for epoch in range(5):  # Run 5 epochs
                    for i, (images, labels) in enumerate(train_dataset):
                        with tf.device(device):
                            with tf.GradientTape() as tape:
                                predictions = model(images, training=True)
                                loss = loss_fn(labels, predictions)
                            gradients = tape.gradient(loss, model.trainable_variables)
                            optimizer.apply_gradients(zip(gradients, model.trainable_variables))

                        # Log every 10 batches
                        if i % 10 == 0:
                            stats = jetson.stats
                            writer.writerow(stats)
                            print(f'Epoch {epoch+1}, Batch {i+1}, Loss: {loss.numpy():.4f}')
                            print(f"Log at {stats['time']}")

                    # Save model weights at the end of each epoch
                    model.save_weights(weights_path)
                    print(f"Model weights saved at {weights_path}")

                # Get the end date and time for the filename
                end_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
                new_file_path = os.path.join(directory, f"cnnlogtrain_{start_time}_to_{end_time}.csv")
                os.rename(file_path, new_file_path)
                print(f"Log file saved as {new_file_path}")

    except JtopException as e:
        print(e)
    except KeyboardInterrupt:
        print("Training interrupted with CTRL-C")
    except IOError:
        print("I/O error")