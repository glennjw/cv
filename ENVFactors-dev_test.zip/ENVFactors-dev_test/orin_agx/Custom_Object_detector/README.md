# ENVFactors

## Usage
Requires the dataset.zip folder to be present in the directory. 
$ python train.py