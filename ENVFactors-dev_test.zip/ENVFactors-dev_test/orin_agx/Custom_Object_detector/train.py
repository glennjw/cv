# import the necessary packages
from sklearn.preprocessing import LabelEncoder
from torch.utils.data import DataLoader
from torchvision import transforms
from torch.utils.data import Dataset
from torch.nn import CrossEntropyLoss
from torch.nn import MSELoss
from torch.nn import Dropout
from torch.nn import Identity
from torch.nn import Linear
from torch.nn import Module
from torch.nn import ReLU
from torch.nn import Sequential
from torch.nn import Sigmoid
from torch.optim import Adam
from torchvision.models import resnet50
from sklearn.model_selection import train_test_split
from imutils import paths
from tqdm import tqdm
import matplotlib.pyplot as plt
import numpy as np
import pickle
import torch
import time
import mimetypes
import imutils
import cv2
import os
import torchvision.transforms as transforms
import csv
import argparse
from jtop import jtop, JtopException
import datetime  
import os

# Check for a GPU


def plt_imshow(title, image):
	# convert the image frame BGR to RGB color space and display it
	image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
	plt.imshow(image)
	plt.title(title)
	plt.grid(False)
	plt.show()
	
class Config:
    # define the base path to the input dataset and then use it to derive
    # the path to the input images and annotation CSV files
    BASE_PATH = "dataset"
    IMAGES_PATH = os.path.sep.join([BASE_PATH, "images"])
    ANNOTS_PATH = os.path.sep.join([BASE_PATH, "annotations"])

    # define the path to the base output directory
    BASE_OUTPUT = "output"

    # define the path to the output model, label encoder, plots output
    # directory, and testing image paths
    MODEL_PATH = os.path.sep.join([BASE_OUTPUT, "detector.pth"])
    LE_PATH = os.path.sep.join([BASE_OUTPUT, "le.pickle"])
    PLOTS_PATH = os.path.sep.join([BASE_OUTPUT, "plots"])
    TEST_PATHS = os.path.sep.join([BASE_OUTPUT, "test_paths.txt"])

    # determine the current device and based on that set the pin memory
    # flag
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    PIN_MEMORY = True if device == "cuda" else False

    # specify ImageNet mean and standard deviation
    MEAN = [0.485, 0.456, 0.406]
    STD = [0.229, 0.224, 0.225]

    # initialize our initial learning rate, number of epochs to train
    # for, and the batch size
    INIT_LR = 1e-4
    NUM_EPOCHS = 5
    BATCH_SIZE = 4

    # specify the loss weights
    LABELS = 1.0
    BBOX = 1.0

# instantiate a config object
config = Config()

# initialize the list of data (images), class labels, target bounding
# box coordinates, and image paths
print("[INFO] loading dataset...")
data = []
labels = []
bboxes = []
imagePaths = []

# loop over all CSV files in the annotations directory
for csvPath in paths.list_files(config.ANNOTS_PATH, validExts=(".csv")):
	# load the contents of the current CSV annotations file
	rows = open(csvPath).read().strip().split("\n")

	# loop over the rows
	for row in rows:
		# break the row into the filename, bounding box coordinates,
		# and class label
		row = row.split(",")
		(filename, startX, startY, endX, endY, label) = row

		# derive the path to the input image, load the image (in
		# OpenCV format), and grab its dimensions
		imagePath = os.path.sep.join([config.IMAGES_PATH, label,
			filename])
		image = cv2.imread(imagePath)
		(h, w) = image.shape[:2]

		# scale the bounding box coordinates relative to the spatial
		# dimensions of the input image
		startX = float(startX) / w
		startY = float(startY) / h
		endX = float(endX) / w
		endY = float(endY) / h

		# load the image and preprocess it
		image = cv2.imread(imagePath)
		image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
		image = cv2.resize(image, (224, 224))

		# update our list of data, class labels, bounding boxes, and
		# image paths
		data.append(image)
		labels.append(label)
		bboxes.append((startX, startY, endX, endY))
		imagePaths.append(imagePath)
		
class CustomTensorDataset(Dataset):
	# initialize the constructor
	def __init__(self, tensors, transforms=None):
		self.tensors = tensors
		self.transforms = transforms

	def __getitem__(self, index):
		# grab the image, label, and its bounding box coordinates
		image = self.tensors[0][index]
		label = self.tensors[1][index]
		bbox = self.tensors[2][index]

		# transpose the image such that its channel dimension becomes
		# the leading one
		image = image.permute(2, 0, 1)

		# check to see if we have any image transformations to apply
		# and if so, apply them
		if self.transforms:
			image = self.transforms(image)

		# return a tuple of the images, labels, and bounding
		# box coordinates
		return (image, label, bbox)

	def __len__(self):
		# return the size of the dataset
		return self.tensors[0].size(0)
	
# convert the data, class labels, bounding boxes, and image paths to
# NumPy arrays
data = np.array(data, dtype="float32")
labels = np.array(labels)
bboxes = np.array(bboxes, dtype="float32")
imagePaths = np.array(imagePaths)

# perform label encoding on the labels
le = LabelEncoder()
labels = le.fit_transform(labels)

# partition the data into training and testing splits using 80% of
# the data for training and the remaining 20% for testing
split = train_test_split(data, labels, bboxes, imagePaths,
	test_size=0.20, random_state=42)

# unpack the data split
(trainImages, testImages) = split[:2]
(trainLabels, testLabels) = split[2:4]
(trainBBoxes, testBBoxes) = split[4:6]
(trainPaths, testPaths) = split[6:]

# convert NumPy arrays to PyTorch tensors
(trainImages, testImages) = torch.tensor(trainImages),\
	torch.tensor(testImages)
(trainLabels, testLabels) = torch.tensor(trainLabels),\
	torch.tensor(testLabels)
(trainBBoxes, testBBoxes) = torch.tensor(trainBBoxes),\
	torch.tensor(testBBoxes)

# define normalization transforms
transforms = transforms.Compose([
	transforms.ToPILImage(),
	transforms.ToTensor(),
	transforms.Normalize(mean=config.MEAN, std=config.STD)
])

# convert NumPy arrays to PyTorch datasets
trainDS = CustomTensorDataset((trainImages, trainLabels, trainBBoxes),
	transforms=transforms)
testDS = CustomTensorDataset((testImages, testLabels, testBBoxes),
	transforms=transforms)
print("[INFO] total training samples: {}...".format(len(trainDS)))
print("[INFO] total test samples: {}...".format(len(testDS)))

# calculate steps per epoch for training and validation set
trainSteps = len(trainDS) // config.BATCH_SIZE
valSteps = len(testDS) // config.BATCH_SIZE


# create data loaders
trainLoader = DataLoader(trainDS, batch_size=config.BATCH_SIZE,
	shuffle=True, num_workers=os.cpu_count(), pin_memory=config.PIN_MEMORY)
testLoader = DataLoader(testDS, batch_size=config.BATCH_SIZE,
	num_workers=os.cpu_count(), pin_memory=config.PIN_MEMORY)


class ObjectDetector(Module):
	def __init__(self, baseModel, numClasses):
		super(ObjectDetector, self).__init__()

		# initialize the base model and the number of classes
		self.baseModel = baseModel
		self.numClasses = numClasses

		# build the regressor head for outputting the bounding box
		# coordinates
		self.regressor = Sequential(
			Linear(baseModel.fc.in_features, 128),
			ReLU(),
			Linear(128, 64),
			ReLU(),
			Linear(64, 32),
			ReLU(),
			Linear(32, 4),
			Sigmoid()
		)

		# build the classifier head to predict the class labels
		self.classifier = Sequential(
			Linear(baseModel.fc.in_features, 512),
			ReLU(),
			Dropout(),
			Linear(512, 512),
			ReLU(),
			Dropout(),
			Linear(512, self.numClasses)
		)

		# set the classifier of our base model to produce outputs
		# from the last convolution block
		self.baseModel.fc = Identity()

	def forward(self, x):
		# pass the inputs through the base model and then obtain
		# predictions from two different branches of the network
		features = self.baseModel(x)
		bboxes = self.regressor(features)
		classLogits = self.classifier(features)

		# return the outputs as a tuple
		return (bboxes, classLogits)
	
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='PyTorch Training with jtop Logger')
    parser.add_argument('--file', action="store", dest="file", default="objlog.csv")
    args = parser.parse_args()

    # Get the current date and time for the filename
    current_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

    # Specify a different directory
    directory = "./OBJlogs"

    if not os.path.exists(directory):
        os.makedirs(directory)
    # Construct the full path with the timestamp
    file_path = os.path.join(directory, f"objlog_{current_time}.csv")
	
    # load the ResNet50 network
    resnet = resnet50(pretrained=True)

    # freeze all ResNet50 layers so they will *not* be updated during the
    # training process
    for param in resnet.parameters():
        param.requires_grad = False

    # create our custom object detector model and flash it to the current
    # device
    objectDetector = ObjectDetector(resnet, len(le.classes_))
    objectDetector = objectDetector.to(config.device)

    # define our loss functions
    classLossFunc = CrossEntropyLoss()
    bboxLossFunc = MSELoss()

    # initialize the optimizer, compile the model, and show the model
    # summary
    opt = Adam(objectDetector.parameters(), lr=config.INIT_LR)
    print(objectDetector)

    # initialize a dictionary to store training history
    H = {"total_train_loss": [], "total_val_loss": [], "train_class_acc": [],
        "val_class_acc": []}
	

    print("Training MNIST with jtop logging")
    print("Saving log on {file}".format(file=args.file))

	

    try:
        with jtop() as jetson:
            with open(file_path, 'w') as csvfile:
                stats = jetson.stats
                writer = csv.DictWriter(csvfile, fieldnames=stats.keys())
                writer.writeheader()
                
                # loop over epochs
                print("[INFO] training the network...")
                startTime = time.time()
                for e in tqdm(range(config.NUM_EPOCHS)):
                    # set the model in training mode
                    objectDetector.train()

                    # initialize the total training and validation loss
                    totalTrainLoss = 0
                    totalValLoss = 0

                    # initialize the number of correct predictions in the training
                    # and validation step
                    trainCorrect = 0
                    valCorrect = 0

                    # loop over the training set
                    for i,(images, labels, bboxes) in enumerate(trainLoader):
                        # send the input to the device
                        (images, labels, bboxes) = (images.to(config.device),
                            labels.to(config.device), bboxes.to(config.device))

                        # perform a forward pass and calculate the training loss
                        predictions = objectDetector(images)
                        bboxLoss = bboxLossFunc(predictions[0], bboxes)
                        classLoss = classLossFunc(predictions[1], labels)
                        totalLoss = (config.BBOX * bboxLoss) + (config.LABELS * classLoss)

                        # zero out the gradients, perform the backpropagation step,
                        # and update the weights
                        opt.zero_grad()
                        totalLoss.backward()
                        opt.step()

                        # Log every 10 batches
                        if i % 5 == 0:
                            stats = jetson.stats
                            writer.writerow(stats)
                            print(f'Epoch {e+1}, Batch {i+1}, Loss: {totalLoss.item():.4f}')
                            print("Log at {time}".format(time=stats['time']))


                        # add the loss to the total training loss so far and
                        # calculate the number of correct predictions
                        totalTrainLoss += totalLoss
                        trainCorrect += (predictions[1].argmax(1) == labels).type(
                            torch.float).sum().item()

                    # switch off autograd
                    with torch.no_grad():
                        # set the model in evaluation mode
                        objectDetector.eval()

                        # loop over the validation set
                        for (images, labels, bboxes) in testLoader:
                            # send the input to the device
                            (images, labels, bboxes) = (images.to(config.device),
                                labels.to(config.device), bboxes.to(config.device))

                            # make the predictions and calculate the validation loss
                            predictions = objectDetector(images)
                            bboxLoss = bboxLossFunc(predictions[0], bboxes)
                            classLoss = classLossFunc(predictions[1], labels)
                            totalLoss = (config.BBOX * bboxLoss) + \
                                (config.LABELS * classLoss)
                            totalValLoss += totalLoss

                            # calculate the number of correct predictions
                            valCorrect += (predictions[1].argmax(1) == labels).type(
                                torch.float).sum().item()

            # calculate the average training and validation loss
            avgTrainLoss = totalTrainLoss / trainSteps
            avgValLoss = totalValLoss / valSteps

            # calculate the training and validation accuracy
            trainCorrect = trainCorrect / len(trainDS)
            valCorrect = valCorrect / len(testDS)

            # update our training history
            H["total_train_loss"].append(avgTrainLoss.cpu().detach().numpy())
            H["train_class_acc"].append(trainCorrect)
            H["total_val_loss"].append(avgValLoss.cpu().detach().numpy())
            H["val_class_acc"].append(valCorrect)

            # print the model training and validation information
            print("[INFO] EPOCH: {}/{}".format(e + 1, config.NUM_EPOCHS))
            print("Train loss: {:.6f}, Train accuracy: {:.4f}".format(
                avgTrainLoss, trainCorrect))
            print("Val loss: {:.6f}, Val accuracy: {:.4f}".format(
                avgValLoss, valCorrect))
        endTime = time.time()
        print("[INFO] total time taken to train the model: {:.2f}s".format(
            endTime - startTime))

    except JtopException as e:
        print(e)
    except KeyboardInterrupt:
        print("Training interrupted with CTRL-C")
    except IOError:
        print("I/O error")