#!/bin/bash
# Execute the first Python script
echo "Running custom CNN ..."
python3 ./Custom_CNN/train_tf.py
python3 ./Custom_CNN/inference.py


# Execute the second Python script
echo "Running image classification..."
# python ./'Image Classification'/train_tf.py --arch "resnet18"
# python ./'Image Classification'/inference.py --arch "resnet18"
python3 ./Image_Classification/train_tf.py --arch "resnet50"
# python ./'Image Classification'/inference.py --arch "resnet50"
python3 ./Image_Classification/train_tf.py --arch "densenet"
# python ./'Image Classification'/inference.py --arch "densenet"
python3 ./Image_Classification/train_tf.py --arch "mobilenet"
#python ./'Image Classification'/inference.py --arch "mobilenet"


# Execute the last Python script in a different Conda environment
echo "Running script3.py in special_env..."
python3 ./Pix2Pix_tf/train.py


# Execute the first Python script
echo "Running custom ObjdDet"
python3 ./Custom_Object_detector/train.py

echo "All scripts executed successfully!"