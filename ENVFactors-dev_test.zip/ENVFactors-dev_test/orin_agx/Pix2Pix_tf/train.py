# import tensorflow and fix the random seed for better reproducibility
import tensorflow as tf
tf.random.set_seed(42)

# import the necessary packages
from tensorflow.keras.preprocessing.image import array_to_img
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.layers import Conv2DTranspose
from tensorflow.keras.layers import LeakyReLU
from tensorflow.keras.layers import concatenate
from tensorflow.keras.layers import MaxPool2D
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import Dropout
from tensorflow.keras.losses import BinaryCrossentropy
from tensorflow.keras.losses import MeanAbsoluteError
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import Callback
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import get_file
from tensorflow.keras import Model
from tensorflow.keras import Input
from matplotlib.pyplot import subplots
import matplotlib.pyplot as plt
import tensorflow as tf
import pathlib
import os
import csv
import argparse
from jtop import jtop, JtopException
import csv
from jtop import jtop, JtopException
import tensorflow as tf
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.losses import BinaryCrossentropy, MeanAbsoluteError
from tensorflow.keras.models import Model
import os
import datetime  
import os



# Check for a GPU
device = "/gpu:0" if tf.config.list_physical_devices('GPU') else "/cpu:0"

class Config(object):
    # name of the dataset we will be using 
    DATASET = "cityscapes"

    # build the dataset URL
    DATASET_URL  = f"http://efrosgans.eecs.berkeley.edu/pix2pix/datasets/{DATASET}.tar.gz"

    # define the batch size
    TRAIN_BATCH_SIZE = 4
    INFER_BATCH_SIZE = 8

    # dataset specs
    IMAGE_WIDTH = 256
    IMAGE_HEIGHT = 256
    IMAGE_CHANNELS = 3

    # training specs
    LEARNING_RATE = 2e-4
    EPOCHS = 5
    STEPS_PER_EPOCH = 15

    # path to the base output directory
    BASE_OUTPUT_PATH = "outputs"
    TEMP_BASE_OUTPUT_PATH = "temp_outputs"

    # path to the pix2pix generator
    GENERATOR_MODEL = os.path.join(
        BASE_OUTPUT_PATH, "models", "generator"
    )
    TEMP_GENERATOR_MODEL = os.path.join(
        TEMP_BASE_OUTPUT_PATH, "models", "generator"
    )

    # path to the inferred images and to the grid image
    BASE_IMAGES_PATH = os.path.join(BASE_OUTPUT_PATH, "images")
    GRID_IMAGE_PATH = os.path.join(BASE_IMAGES_PATH, "grid.png")
    TEMP_BASE_IMAGES_PATH = os.path.join(TEMP_BASE_OUTPUT_PATH, "images")
    TEMP_GRID_IMAGE_PATH = os.path.join(TEMP_BASE_IMAGES_PATH, "grid.png")

config = Config()

# download the cityscape training dataset 
print("[INFO] downloading the dataset...")
pathToZip = tf.keras.utils.get_file(
    fname=f"{config.DATASET}.tar.gz",
    origin=config.DATASET_URL,
    extract=True
)
pathToZip  = pathlib.Path(pathToZip)
path = pathToZip.parent / config.DATASET

## Dataset Utilities
# define the module level autotune
AUTO = tf.data.AUTOTUNE

def load_image(imageFile):
    # read and decode an image file from the path
    image = tf.io.read_file(imageFile)
    image = tf.io.decode_jpeg(image, channels=3)

    # calculate the midpoint of the width and split the
    # combined image into input mask and real image 
    width = tf.shape(image)[1]
    splitPoint = width // 2
    inputMask = image[:, splitPoint:, :]
    realImage = image[:, :splitPoint, :]

    # convert both images to float32 tensors and
    # convert pixels to the range of -1 and 1
    inputMask = tf.cast(inputMask, tf.float32)/127.5 - 1
    realImage = tf.cast(realImage, tf.float32)/127.5 - 1

    # return the input mask and real label image
    return (inputMask, realImage)

def random_jitter(inputMask, realImage, height, width):
    # upscale the images for cropping purposes
    inputMask = tf.image.resize(inputMask, [height, width],
        method=tf.image.ResizeMethod.NEAREST_NEIGHBOR)
    realImage = tf.image.resize(realImage, [height, width],
        method=tf.image.ResizeMethod.NEAREST_NEIGHBOR)

    # return the input mask and real label image
    return (inputMask, realImage)

class ReadTrainExample(object):
    def __init__(self, imageHeight, imageWidth):
        self.imageHeight = imageHeight
        self.imageWidth = imageWidth
    
    def __call__(self, imageFile):
        # read the file path and unpack the image pair
        inputMask, realImage = load_image(imageFile)

        # perform data augmentation
        (inputMask, realImage) = random_jitter(inputMask, realImage,
            self.imageHeight+30, self.imageWidth+30)

        # reshape the input mask and real label image
        inputMask = tf.image.resize(inputMask,
            [self.imageHeight, self.imageWidth])
        realImage = tf.image.resize(realImage,
            [self.imageHeight, self.imageWidth])

        # return the input mask and real label image
        return (inputMask, realImage)
    

class ReadTestExample(object):
    def __init__(self, imageHeight, imageWidth):
        self.imageHeight = imageHeight
        self.imageWidth = imageWidth

    def __call__(self, imageFile):
        # read the file path and unpack the image pair
        (inputMask, realImage) = load_image(imageFile)

        # reshape the input mask and real label image
        inputMask = tf.image.resize(inputMask,
            [self.imageHeight, self.imageWidth])
        realImage = tf.image.resize(realImage,
            [self.imageHeight, self.imageWidth])

        # return the input mask and real label image
        return (inputMask, realImage)
    

def load_dataset(path, batchSize, height, width, train=False):
    # check if this is the training dataset
    if train:
        # read the training examples
        dataset = tf.data.Dataset.list_files(str(path/"train/*.jpg"))
        dataset = dataset.map(ReadTrainExample(height, width),
            num_parallel_calls=AUTO)
    # otherwise, we are working with the test dataset
    else:
        # read the test examples
        dataset = tf.data.Dataset.list_files(str(path/"val/*.jpg"))
        dataset = dataset.map(ReadTestExample(height, width),
            num_parallel_calls=AUTO)

    # shuffle, batch, repeat and prefetch the dataset
    dataset = (dataset
        .shuffle(batchSize * 2)
        .batch(batchSize)
        .repeat()
        .prefetch(AUTO)
    )

    # return the dataset
    return dataset

# build the training dataset
print("[INFO] building the train dataset...")
trainDs = load_dataset(path=path, train=True,
    batchSize=config.TRAIN_BATCH_SIZE, height=config.IMAGE_HEIGHT,
    width=config.IMAGE_WIDTH)

# build the test dataset
print("[INFO] building the test dataset...")
testDs = load_dataset(path=path, train=False,
    batchSize=config.INFER_BATCH_SIZE, height=config.IMAGE_HEIGHT,
    width=config.IMAGE_WIDTH)

### Model Utilities
class Pix2Pix(object):
    def __init__(self, imageHeight, imageWidth):
        # initialize the image height and width
        self.imageHeight = imageHeight
        self.imageWidth = imageWidth

    def generator(self):
        # initialize the input layer
        inputs = Input([self.imageHeight, self.imageWidth, 3])
  
        # down Layer 1 (d1) => final layer 1 (f1)
        d1 = Conv2D(32, (3, 3), activation="relu", padding="same")(
            inputs)
        d1 = Dropout(0.1)(d1)
        f1 = MaxPool2D((2, 2))(d1)

        # down Layer 2 (l2) => final layer 2 (f2)
        d2 = Conv2D(64, (3, 3), activation="relu", padding="same")(f1)
        f2 = MaxPool2D((2, 2))(d2)

        #  down Layer 3 (l3) => final layer 3 (f3)
        d3 = Conv2D(96, (3, 3), activation="relu", padding="same")(f2)
        f3 = MaxPool2D((2, 2))(d3)

        # down Layer 4 (l3) => final layer 4 (f4)
        d4 = Conv2D(96, (3, 3), activation="relu", padding="same")(f3)
        f4 = MaxPool2D((2, 2))(d4)

        # u-bend of the u-bet
        b5 = Conv2D(96, (3, 3), activation="relu", padding="same")(f4)
        b5 = Dropout(0.3)(b5)
        b5 = Conv2D(256, (3, 3), activation="relu", padding="same")(b5)

        # upsample Layer 6 (u6)
        u6 = Conv2DTranspose(128, (2, 2), strides=(2, 2),
            padding="same")(b5)
        u6 = concatenate([u6, d4])
        u6 = Conv2D(128, (3, 3), activation="relu", padding="same")(
            u6)

        # upsample Layer 7 (u7)
        u7 = Conv2DTranspose(96, (2, 2), strides=(2, 2),
            padding="same")(u6)
        u7 = concatenate([u7, d3])
        u7 = Conv2D(128, (3, 3), activation="relu", padding="same")(
            u7)

        # upsample Layer 8 (u8)
        u8 = Conv2DTranspose(64, (2, 2), strides=(2, 2),
            padding="same")(u7)
        u8 = concatenate([u8, d2])
        u8 = Conv2D(128, (3, 3), activation="relu", padding="same")(u8)

        # upsample Layer 9 (u9)
        u9 = Conv2DTranspose(32, (2, 2), strides=(2, 2),
            padding="same")(u8)
        u9 = concatenate([u9, d1])
        u9 = Dropout(0.1)(u9)
        u9 = Conv2D(128, (3, 3), activation="relu", padding="same")(u9)

        # final conv2D layer
        outputLayer = Conv2D(3, (1, 1), activation="tanh")(u9)
    
        # create the generator model
        generator = Model(inputs, outputLayer)

        # return the generator
        return generator

    def discriminator(self):
        # initialize input layer according to PatchGAN
        inputMask = Input(shape=[self.imageHeight, self.imageWidth, 3], 
            name="input_image"
        )
        targetImage = Input(
            shape=[self.imageHeight, self.imageWidth, 3], 
            name="target_image"
        )
  
        # concatenate the inputs
        x = concatenate([inputMask, targetImage])  

        # add four conv2D convolution layers
        x = Conv2D(64, 4, strides=2, padding="same")(x)  
        x = LeakyReLU()(x)
        x = Conv2D(128, 4, strides=2, padding="same")(x)
        x = LeakyReLU()(x)  
        x = Conv2D(256, 4, strides=2, padding="same")(x)
        x = LeakyReLU()(x)   
        x = Conv2D(512, 4, strides=1, padding="same")(x)  

        # add a batch-normalization layer => LeakyReLU => zeropad
        x = BatchNormalization()(x)
        x = LeakyReLU()(x)

        # final conv layer
        last = Conv2D(1, 3, strides=1)(x) 
  
        # create the discriminator model
        discriminator = Model(inputs=[inputMask, targetImage],
            outputs=last)

        # return the discriminator
        return discriminator
	

# initialize the generator and discriminator network
print("[INFO] initializing the generator and discriminator...")
pix2pixObject = Pix2Pix(imageHeight=config.IMAGE_HEIGHT,
    imageWidth=config.IMAGE_WIDTH)
generator = pix2pixObject.generator()
discriminator = pix2pixObject.discriminator()

### Module change
class Pix2PixTraining(Model):
    def __init__(self, generator, discriminator):
        super().__init__()
        self.generator = generator
        self.discriminator = discriminator

    def compile(self, gOptimizer, dOptimizer, bceLoss, maeLoss):
        super().compile()
        self.gOptimizer = gOptimizer
        self.dOptimizer = dOptimizer
        self.bceLoss = bceLoss
        self.maeLoss = maeLoss

    def train_step(self, inputs):
        # grab the input mask and corresponding real images
        (inputMask, realImages) = inputs

        # initialize gradient tapes for both generator and discriminator
        with tf.GradientTape() as genTape, tf.GradientTape() as discTape:
            # generate fake images
            fakeImages = self.generator(inputMask, training=True)

            # discriminator output for real images and fake images
            discRealOutput = self.discriminator(
                [inputMask, realImages], training=True)
            discFakeOutput = self.discriminator(
                [inputMask, fakeImages], training=True)

            # compute the adversarial loss for the generator
            misleadingImageLabels = tf.ones_like(discFakeOutput) 
            ganLoss = self.bceLoss(misleadingImageLabels, discFakeOutput)

            # compute the mean absolute error between the fake and the
            # real images
            l1Loss = self.maeLoss(realImages, fakeImages)

            # compute the total generator loss
            totalGenLoss = ganLoss + (10 * l1Loss)

            # discriminator loss for real and fake images
            realImageLabels = tf.ones_like(discRealOutput)
            realDiscLoss = self.bceLoss(realImageLabels, discRealOutput)
            fakeImageLabels = tf.zeros_like(discFakeOutput)
            generatedLoss = self.bceLoss(fakeImageLabels, discFakeOutput)

            # compute the total discriminator loss
            totalDiscLoss = realDiscLoss + generatedLoss

        # calculate the generator and discriminator gradients
        generatorGradients = genTape.gradient(totalGenLoss, 
            self.generator.trainable_variables
        )
        discriminatorGradients = discTape.gradient(totalDiscLoss, 
            self.discriminator.trainable_variables
        )

        # apply the gradients to optimize the generator and discriminator
        self.gOptimizer.apply_gradients(zip(generatorGradients,
            self.generator.trainable_variables)
        )
        self.dOptimizer.apply_gradients(zip(discriminatorGradients,
            self.discriminator.trainable_variables)
        )

        # return the generator and discriminator losses
        return {"dLoss": totalDiscLoss, "gLoss": totalGenLoss}
    
    def train_model(self, dataset, epochs, steps_per_epoch, log_file):
        start_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        
        with jtop() as jetson:
            with open(log_file, 'w', newline='') as file:
                stats = jetson.stats
                writer = csv.DictWriter(file, fieldnames=stats.keys())
                writer.writeheader()
                writer.writerow(stats)

                for epoch in range(epochs):
                    for batch in range(steps_per_epoch):
                        inputs = next(iter(dataset))  # Adjust based on your dataset iteration
                        losses = self.train_step(inputs)
                        stats = jetson.stats

                        writer.writerow(stats)

                        print(f"Epoch {epoch + 1}, Batch {batch + 1}, D Loss: {losses['dLoss']}, G Loss: {losses['gLoss']}")

                end_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
                new_log_file = log_file.replace(".csv", f"_{start_time}_to_{end_time}.csv")
                os.rename(log_file, new_log_file)

                print("[INFO] Training complete.")
                print(f"Log file saved as {new_log_file}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='TensorFlow Pix2Pix Training with jtop Logger')
    parser.add_argument('--file', action="store", dest="file", default="log.csv")
    args = parser.parse_args()

    # Get the current date and time for the filename
    current_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    # Specify a different directory

    directory = "./P2Plogs"
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Construct the full path with the timestamp
    file_path = os.path.join(directory, f"p2plog_{current_time}.csv")
	
    # Assuming `trainDs` is defined, and `Pix2PixTraining` instance is set up
    pix2pixModel = Pix2PixTraining(generator=generator, discriminator=discriminator)
    pix2pixModel.compile(
        dOptimizer=Adam(learning_rate=config.LEARNING_RATE),
        gOptimizer=Adam(learning_rate=config.LEARNING_RATE),
        bceLoss=BinaryCrossentropy(from_logits=True),
        maeLoss=MeanAbsoluteError()
    )

    # Create directories if they do not exist
    os.makedirs(config.TEMP_BASE_OUTPUT_PATH, exist_ok=True)
    os.makedirs(config.TEMP_BASE_IMAGES_PATH, exist_ok=True)

    # Now, manually start training with logging
    print("[INFO] training the pix2pix model...")
    pix2pixModel.train_model(trainDs, config.EPOCHS, config.STEPS_PER_EPOCH, log_file=file_path)