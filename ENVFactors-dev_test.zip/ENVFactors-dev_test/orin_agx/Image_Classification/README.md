# ENVFactors
# usage: python train.py --arch resnet50 (Choose between resnet50, restnet18, densenet, mobilenet)