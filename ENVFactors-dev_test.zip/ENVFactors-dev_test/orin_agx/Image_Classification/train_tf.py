import tensorflow as tf
import numpy as np
import csv
import argparse
import datetime
import os
from jtop import jtop, JtopException


def get_model(arch):
    if arch == 'resnet18':
        base_model = tf.keras.applications.ResNet50V2(include_top=False, weights=None, input_shape=(32, 32, 3))
    elif arch == 'resnet50':
        base_model = tf.keras.applications.ResNet50(include_top=False, weights=None, input_shape=(32, 32, 3))
    elif arch == 'densenet':
        base_model = tf.keras.applications.DenseNet121(include_top=False, weights=None, input_shape=(32, 32, 3))
    elif arch == 'mobilenet':
        base_model = tf.keras.applications.MobileNetV2(include_top=False, weights=None, input_shape=(32, 32, 3))
    else:
        raise ValueError("Invalid architecture. Choose from 'resnet18', 'resnet50', 'densenet', or 'mobilenet'.")

    model = tf.keras.models.Sequential([
        base_model,
        tf.keras.layers.GlobalAveragePooling2D(),
        tf.keras.layers.Dense(10, activation='softmax')
    ])

    return model

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train an image classification model on CIFAR-10 dataset with different architectures.")
    parser.add_argument("--arch", type=str, choices=['resnet18', 'resnet50', 'densenet', 'mobilenet'], default='resnet18', help="Choose model architecture (default: resnet18)")
    parser.add_argument('--file', action="store", dest="file", default="imglog.csv", help="Specify the file name for logging (default: log.csv)")
    args = parser.parse_args()

    # Get the start date and time for the filename
    start_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    # Specify a different directory
    directory = "./IMGlogs"
    if not os.path.exists(directory):
        os.makedirs(directory)

    if args.arch == "resnet18":
        args.file = "r18log.csv"
    elif args.arch == "resnet50":
        args.file = "r50log.csv"
    elif args.arch == "densenet":
        args.file = "dnetlog.csv"
    elif args.arch == "mobilenet":
        args.file = "mbnetlog.csv"

    # Check for a GPU
    device = "/gpu:0" if tf.config.list_physical_devices('GPU') else "/cpu:0"

    # Data preprocessing and augmentation
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()
    x_train, x_test = x_train / 255.0, x_test / 255.0

    train_datagen = tf.keras.preprocessing.image.ImageDataGenerator(
        featurewise_center=False,
        samplewise_center=False,
        featurewise_std_normalization=False,
        samplewise_std_normalization=False,
        zca_whitening=False,
        rotation_range=15,
        width_shift_range=0.1,
        height_shift_range=0.1,
        horizontal_flip=True,
        vertical_flip=False
    )

    train_generator = train_datagen.flow(x_train, y_train, batch_size=4)

    model = get_model(args.arch)
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

    epochs = 5

    try:
        with jtop() as jetson:
            with open(os.path.join(directory, f"imglogtrain_{args.arch}_{start_time}.csv"), 'w') as csvfile:
                stats = jetson.stats
                writer = csv.DictWriter(csvfile, fieldnames=stats.keys())
                writer.writeheader()

                for epoch in range(epochs):
                    for i, (images, labels) in enumerate(train_generator):
                        with tf.device(device):
                            history = model.fit(images, labels, epochs=1, verbose=0)

                        # Log every 10 batches
                        if i % 10 == 0:
                            stats = jetson.stats
                            writer.writerow(stats)
                            print(f'Epoch {epoch+1}, Batch {i+1}, Loss: {history.history["loss"][0]:.4f}, Accuracy: {history.history["accuracy"][0]:.4f}')
                            print(f"Log at {stats['time']}")

                        if i * 32 >= len(x_train):
                            break

                # Get the end date and time for the filename
                end_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
                os.rename(
                    os.path.join(directory, f"imglogtrain_{args.arch}_{start_time}.csv"),
                    os.path.join(directory, f"imglogtrain_{args.arch}_{start_time}_to_{end_time}.csv")
                )

                test_loss, test_acc = model.evaluate(x_test, y_test, verbose=2)
                print(f'Accuracy of the network on the 10000 test images: {test_acc * 100:.2f} %')

    except JtopException as e:
        print(e)
    except KeyboardInterrupt:
        print("Training interrupted with CTRL-C")
    except IOError:
        print("I/O error")