import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import torch
import torchvision
import torchvision.transforms as transforms
from torch import nn, optim
from torch.utils.data import DataLoader
from jtop import jtop, JtopException
import csv
import argparse
import numpy as np
import numpy
import datetime  
import os


def get_model(arch):
    # Choice between 4 models
    if arch == 'resnet18':
        model = torchvision.models.resnet18(pretrained=False)
    elif arch == 'resnet50':
        model = torchvision.models.resnet50(pretrained=False)
    elif arch == 'densenet':
        model = torchvision.models.densenet121(pretrained=False)
    elif arch == 'mobilenet':
        model = torchvision.models.mobilenet_v2(pretrained=False)
    else:
        raise ValueError("Invalid architecture. Choose from 'resnet18', 'resnet50', 'densenet', or 'mobilenet'.")

    if arch != 'mobilenet':
        num_ftrs = model.fc.in_features
        model.fc = nn.Linear(num_ftrs, 10)  

    return model



if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Train an image classification model on CIFAR-10 dataset with different architectures.")
    parser.add_argument("--arch", type=str, choices=['resnet18', 'resnet50', 'densenet', 'mobilenet'], default='resnet18', help="Choose model architecture (default: resnet18)")

    parser.add_argument('--file', action="store", dest="file", default="imglog.csv", help="Specify the file name for logging (default: log.csv)")
    args = parser.parse_args()
    #main(args.arch)

    # Get the current date and time for the filename
    current_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    # Specify a different directory
    directory = "./IMGlogs"
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Construct the full path with the timestamp
    file_path = os.path.join(directory, f"imglog_{current_time}.csv")


    if args.arch == "resnet18":
        args.file = "r18log.csv"
    elif args.arch == "resnet50":
        args.file = "r50log.csv"
    elif args.arch == "densenet":
        args.file = "dnetlog.csv"
    elif args.arch == "mobinenet":
        args.file = "mbnetlog.csv"
    # Check for a GPU
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # basic transformations for data
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    # Download cifar10
    trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
    trainloader = torch.utils.data.DataLoader(trainset, batch_size=32, shuffle=True, num_workers=2)

    # Download cifar10 test
    testset = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)
    testloader = torch.utils.data.DataLoader(testset, batch_size=32, shuffle=False, num_workers=2)

    # classes
    classes = ('plane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck')

    model = get_model(args.arch)
    model.to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=0.001, momentum=0.9)

    epochs = 1
    
    try:
        with jtop() as jetson:
            with open(file_path, 'w') as csvfile:
                stats = jetson.stats
                writer = csv.DictWriter(csvfile, fieldnames=stats.keys())
                writer.writeheader()

                for epoch in range(epochs): 
                    running_loss = 0.0
                    for i, data in enumerate(trainloader, 0):
                        inputs, labels = data

                        optimizer.zero_grad()

                        outputs = model(inputs)
                        loss = criterion(outputs, labels)
                        loss.backward()
                        optimizer.step()

                        running_loss += loss.item()
                        if i % 100 == 99:
                            print('[%d, %5d] loss: %.3f' % (epoch + 1, i + 1, running_loss / 100))
                            running_loss = 0.0

                        # Log every 10 batches
                        if i % 10 == 0:
                            stats = jetson.stats
                            writer.writerow(stats)
                            print(f'Epoch {epoch+1}, Batch {i+1}, Loss: {loss.item():.4f}')
                            print("Log at {time}".format(time=stats['time']))

                correct = 0
                total = 0
                with torch.no_grad():
                    for data in testloader:
                        images, labels = data
                        outputs = model(images)
                        _, predicted = torch.max(outputs.data, 1)
                        total += labels.size(0)
                        correct += (predicted == labels).sum().item()
                
                print('Accuracy of the network on the 10000 test images: %d %%' % (100 * correct / total))
    
    except JtopException as e:
        print(e)
    except KeyboardInterrupt:
        print("Training interrupted with CTRL-C")
    except IOError:
        print("I/O error")