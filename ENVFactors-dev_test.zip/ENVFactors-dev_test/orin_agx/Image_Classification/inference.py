import tensorflow as tf
import numpy as np
import csv
import argparse
import datetime
import os
from jtop import jtop, JtopException

# Check for a GPU
device = "/gpu:0" if tf.config.list_physical_devices('GPU') else "/cpu:0"

# Load and preprocess CIFAR-10 dataset
def preprocess_cifar10_image(image):
    image = tf.image.resize(image, [224, 224])
    image = tf.keras.applications.resnet.preprocess_input(image)
    return image

def load_cifar10_data():
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()
    x_test = tf.convert_to_tensor(x_test, dtype=tf.float32)
    y_test = tf.convert_to_tensor(y_test, dtype=tf.int64)
    return (x_train, y_train), (x_test, y_test)

def get_model(arch):
    if arch == 'resnet18':
        model = tf.keras.applications.ResNet50(weights='imagenet', input_shape=(224, 224, 3))
    elif arch == 'resnet50':
        model = tf.keras.applications.ResNet50(weights='imagenet', input_shape=(224, 224, 3))
    elif arch == 'densenet':
        model = tf.keras.applications.DenseNet121(weights='imagenet', input_shape=(224, 224, 3))
    elif arch == 'mobilenet':
        model = tf.keras.applications.MobileNetV2(weights='imagenet', input_shape=(224, 224, 3))
    else:
        raise ValueError("Invalid architecture. Choose from 'resnet18', 'resnet50', 'densenet', or 'mobilenet'.")
    
    return model

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='TensorFlow Inference with jtop Logger')
    parser.add_argument('--arch', type=str, choices=['resnet18', 'resnet50', 'densenet', 'mobilenet'], default='resnet18', help='Choose model architecture (default: resnet18)')
    parser.add_argument('--file', action="store", dest="file", default="inf_log.csv", help="Specify the file name for logging (default: inf_log.csv)")
    args = parser.parse_args()

    # Get the start date and time for the filename
    start_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    # Specify a different directory
    directory = "./InferenceLogs"
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Construct the full path with the timestamp
    file_path = os.path.join(directory, f"inf_log_{start_time}.csv")

    print(f"Running inference on CIFAR-10 with {args.arch} and jtop logging")
    print(f"Saving log on {file_path}")

    # Load model
    model = get_model(args.arch)

    # Load and preprocess CIFAR-10 data
    (_, _), (x_test, y_test) = load_cifar10_data()
    x_test = tf.data.Dataset.from_tensor_slices(x_test)
    x_test = x_test.map(preprocess_cifar10_image).batch(32)

    try:
        with jtop() as jetson:
            with open(file_path, 'w') as csvfile:
                stats = jetson.stats
                writer = csv.DictWriter(csvfile, fieldnames=stats.keys())
                writer.writeheader()

                for i, batch in enumerate(x_test):
                    with tf.device(device):
                        predictions = model(batch, training=False)

                    # Log every batch
                    if i % 10 == 0:
                        stats = jetson.stats
                        writer.writerow(stats)
                        print(f'Batch {i+1}, Predictions: {predictions.shape}')
                        print(f"Log at {stats['time']}")

                # Get the end date and time for the filename
                end_time = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
                new_file_path = os.path.join(directory, f"imginf_log_{start_time}_to_{end_time}.csv")
                os.rename(file_path, new_file_path)
                print(f"Log file saved as {new_file_path}")

    except JtopException as e:
        print(e)
    except KeyboardInterrupt:
        print("Inference interrupted with CTRL-C")
    except IOError:
        print("I/O error")